import React, { useState } from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import LearningModules from './components/LearningModules';
import ArticleSource from './components/ArticleSource';
import PersonalActionPlan from './components/PersonalActionPlan';
import { View } from './types';

const App: React.FC = () => {
    const [currentView, setCurrentView] = useState<View>('dashboard');

    const renderView = () => {
        switch (currentView) {
            case 'dashboard':
                return <Dashboard setView={setCurrentView} />;
            case 'modules':
                return <LearningModules />;
            case 'articles':
                return <ArticleSource />;
            case 'plan':
                return <PersonalActionPlan />;
            default:
                return <Dashboard setView={setCurrentView} />;
        }
    };

    return (
        <div className="min-h-screen bg-gray-900 text-gray-200 antialiased">
            <Header currentView={currentView} setView={setCurrentView} />
            <main className="p-4 sm:p-6 md:p-8 max-w-7xl mx-auto">
                {renderView()}
            </main>
            <footer className="text-center p-4 text-gray-500 text-sm">
                © 2024 PT Auto Jaya. Platform Pelatihan Internal.
            </footer>
        </div>
    );
};

export default App;