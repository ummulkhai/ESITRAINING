import React from 'react';
import { Module, Article } from './types';

export const LEARNING_MODULES: Module[] = [
    {
        icon: <IconHeartHandshake />,
        title: "Memahami Pelanggan Otomotif",
        summary: "Fokus pada empati untuk membaca kebutuhan tersembunyi pelanggan, baik itu tentang keamanan keluarga, efisiensi bisnis, atau gaya hidup.",
        content: [
            {
                heading: "Mendengarkan Aktif di Showroom",
                points: [
                    "Perhatikan tidak hanya apa yang dikatakan, tetapi juga bahasa tubuh dan antusiasme mereka terhadap fitur tertentu.",
                    "Ulangi kebutuhan mereka dengan kata-kata Anda sendiri untuk memastikan pemahaman (misal: 'Jadi, prioritas utama Bapak/Ibu adalah kabin yang lega untuk keluarga, ya?').",
                    "Gali lebih dalam dengan pertanyaan terbuka: 'Fitur apa yang paling penting bagi Anda dalam mobil sehari-hari?'"
                ]
            },
            {
                heading: "Empati Terhadap Kekhawatiran",
                points: [
                    "Validasi kekhawatiran mereka tentang biaya, perawatan, atau purna jual. 'Saya paham, biaya perawatan memang jadi pertimbangan penting.'",
                    "Alih-alih membantah, tawarkan solusi dan informasi yang menenangkan.",
                ]
            }
        ]
    },
    {
        icon: <IconShieldCheck />,
        title: "Membangun Kepercayaan",
        summary: "Kepercayaan adalah fondasi penjualan jangka panjang. Pelajari cara menjadi penasihat terpercaya, bukan hanya seorang penjual.",
        content: [
            {
                heading: "Transparansi adalah Kunci",
                points: [
                    "Jujur tentang kelebihan dan keterbatasan sebuah model mobil. Ini membangun kredibilitas.",
                    "Jelaskan struktur harga dan promosi dengan jelas tanpa biaya tersembunyi.",
                    "Jika Anda tidak tahu jawaban, katakan terus terang dan berjanji akan mencari tahu."
                ]
            },
            {
                heading: "Konsistensi dan Tindak Lanjut",
                points: [
                    "Tepati semua janji, sekecil apa pun (misal: mengirim brosur via WhatsApp).",
                    "Lakukan tindak lanjut pasca-test drive atau kunjungan tanpa terkesan memaksa.",
                ]
            }
        ]
    },
    {
        icon: <IconBrainCircuit />,
        title: "Mengelola Emosi Saat Negosiasi",
        summary: "Tetap tenang, positif, dan fokus pada solusi saat menghadapi tekanan, penolakan, atau negosiasi yang alot dari pelanggan.",
        content: [
            {
                heading: "Kesadaran Diri di Bawah Tekanan",
                points: [
                    "Kenali pemicu emosi Anda (misal: pelanggan yang membandingkan dengan kompetitor secara agresif).",
                    "Ambil jeda singkat jika perlu. 'Mohon waktu sebentar, saya akan cek opsi terbaik untuk Anda.'",
                    "Fokus pada pernapasan untuk tetap tenang dan berpikir jernih."
                ]
            },
            {
                heading: "Mengubah Penolakan Menjadi Peluang",
                points: [
                    "Jangan ambil penolakan secara pribadi. Ini adalah bagian dari proses.",
                    "Lihat penolakan harga sebagai sinyal untuk lebih menekankan nilai dan manfaat jangka panjang mobil.",
                    "Gunakan teknik 'Feel, Felt, Found': 'Saya paham apa yang Anda rasakan (feel), banyak pelanggan kami juga merasa begitu pada awalnya (felt), namun mereka menemukan (found) bahwa...'."
                ]
            }
        ]
    },
    {
        icon: <IconMegaphone />,
        title: "Komunikasi Persuasif",
        summary: "Pengaruhi keputusan pelanggan secara positif dengan komunikasi yang jelas, menarik, dan beresonansi dengan kebutuhan mereka.",
        content: [
            {
                heading: "Storytelling, Bukan Sekadar Spek",
                points: [
                    "Alih-alih hanya menyebut 'kapasitas 7-seater', ceritakan 'bayangkan kenyamanan seluruh keluarga saat mudik Lebaran tanpa perlu berdesakan.'",
                    "Hubungkan fitur (misal: 'Advanced Safety Features') dengan manfaat emosional ('memberikan ketenangan pikiran saat membawa anak-anak')."
                ]
            },
            {
                heading: "Menangani Keberatan dengan Elegan",
                points: [
                    "Dengarkan keberatan sampai selesai tanpa memotong.",
                    "Akui keberatan mereka sebelum memberikan solusi atau perspektif lain.",
                    "Siapkan jawaban berbasis fakta dan testimoni untuk keberatan yang umum."
                ]
            }
        ]
    }
];

export const ARTICLES: Article[] = [
    {
        icon: <IconBookOpen />,
        title: "Kecerdasan Emosional dalam Penjualan Kompetitif",
        source: "Adaptasi dari Harvard Business Review",
        keyTakeaways: [
            "Sales dengan EQ tinggi 2x lebih mungkin melampaui target.",
            "Empati memungkinkan Anda untuk menyesuaikan 'pitch' Anda secara real-time.",
            "Manajemen diri mencegah emosi negatif (seperti frustasi) merusak hubungan dengan klien.",
            "Kesadaran sosial membantu membaca dinamika non-verbal di showroom."
        ]
    },
    {
        icon: <IconNewspaper />,
        title: "Seni Mendengar: Kunci Membuka Kebutuhan Pelanggan",
        source: "Disarikan dari Forbes",
        keyTakeaways: [
            "Tujuan utama mendengar bukan untuk merespon, tetapi untuk memahami.",
            "Biarkan ada jeda hening; seringkali pelanggan akan memberikan informasi paling berharga di momen tersebut.",
            "Tanyakan 'mengapa' di balik sebuah permintaan fitur untuk menemukan motivasi sebenarnya.",
            "Umpan balik non-verbal (mengangguk, kontak mata) menunjukkan Anda terlibat penuh."
        ]
    },
    {
        icon: <IconUsers />,
        title: "Membangun Hubungan, Bukan Hanya Menjual Transaksi",
        source: "Intisari dari Inc. Magazine",
        keyTakeaways: [
            "Fokus pada nilai seumur hidup pelanggan (Lifetime Value), bukan hanya penjualan tunggal.",
            "Ingat detail kecil tentang pelanggan (misal: hobi, keluarga) dan sebutkan dalam percakapan selanjutnya.",
            "Tawarkan bantuan tulus bahkan jika itu tidak langsung mengarah pada penjualan.",
            "Jadilah sumber informasi terpercaya tentang tren otomotif, bukan hanya produk Anda."
        ]
    }
];


// --- Helper Icon Components ---
function IconHeartHandshake() {
    return <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207" /></svg>;
}
function IconShieldCheck() {
    return <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 20.917l9-3.462 9 3.462a12.02 12.02 0 00-2.382-8.94z" /></svg>;
}
function IconBrainCircuit() {
    return <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 8h6M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>;
}
function IconMegaphone() {
    return <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-2.236 9.168-5.514M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>;
}
function IconBookOpen() {
    return <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.523 5.754 19 7.5 19s3.332-.477 4.5-1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.523 18.247 19 16.5 19s-3.332-.477-4.5-1.253" /></svg>;
}
function IconNewspaper() {
    return <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-teal-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3h9M7 16h6M7 12h6M7 8h6" /></svg>;
}
function IconUsers() {
    return <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-rose-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
}
export function IconClipboardList() {
    return <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>;
}