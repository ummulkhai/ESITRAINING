import React from 'react';
import { LEARNING_MODULES } from '../constants';
import ModuleCard from './ModuleCard';

const LearningModules: React.FC = () => {
    return (
        <div>
            <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-white sm:text-4xl">Modul Pembelajaran KES Otomotif</h2>
                <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">Klik setiap modul untuk melihat strategi dan contoh penerapan di lapangan.</p>
            </div>
            <div className="max-w-3xl mx-auto space-y-4">
                {LEARNING_MODULES.map((module, index) => (
                    <ModuleCard key={index} module={module} />
                ))}
            </div>
        </div>
    );
};

export default LearningModules;
