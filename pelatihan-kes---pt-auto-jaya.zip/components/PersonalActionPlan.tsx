import React, { useState, useEffect } from 'react';
import { ActionPlan, ActionStep } from '../types';
import Card from './common/Card';
import Button from './common/Button';

const PersonalActionPlan: React.FC = () => {
    const [plan, setPlan] = useState<ActionPlan>({ goal: '', steps: [] });
    const [newStepText, setNewStepText] = useState('');

    useEffect(() => {
        try {
            const savedPlan = localStorage.getItem('personalActionPlan');
            if (savedPlan) {
                setPlan(JSON.parse(savedPlan));
            }
        } catch (error) {
            console.error("Failed to parse action plan from localStorage", error);
            // Optionally, clear the corrupted data
            localStorage.removeItem('personalActionPlan');
        }
    }, []);

    useEffect(() => {
        localStorage.setItem('personalActionPlan', JSON.stringify(plan));
    }, [plan]);

    const handleGoalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setPlan({ ...plan, goal: e.target.value });
    };

    const handleAddStep = () => {
        if (newStepText.trim() === '') return;
        const newStep: ActionStep = {
            id: Date.now(),
            text: newStepText,
            completed: false,
        };
        setPlan({ ...plan, steps: [...plan.steps, newStep] });
        setNewStepText('');
    };

    const handleToggleStep = (id: number) => {
        setPlan({
            ...plan,
            steps: plan.steps.map(step =>
                step.id === id ? { ...step, completed: !step.completed } : step
            ),
        });
    };
    
    const handleDeleteStep = (id: number) => {
        setPlan({
            ...plan,
            steps: plan.steps.filter(step => step.id !== id),
        });
    };
    
    const handleClearPlan = () => {
        if (window.confirm("Apakah Anda yakin ingin menghapus seluruh rencana aksi? Tindakan ini tidak dapat diurungkan.")) {
            setPlan({ goal: '', steps: [] });
        }
    };

    return (
        <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-white sm:text-4xl">Rencana Aksi Pribadi Anda</h2>
                <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">Tuliskan tujuanmu dan langkah-langkah nyata untuk mengaplikasikan KES dalam pekerjaan sehari-hari.</p>
            </div>
            
            <div className="space-y-6">
                <Card>
                    <label htmlFor="goal" className="block text-lg font-semibold text-red-400 mb-2">Tujuan Utama Saya</label>
                    <input
                        id="goal"
                        type="text"
                        value={plan.goal}
                        onChange={handleGoalChange}
                        placeholder="Contoh: Menjadi lebih baik dalam memahami kebutuhan pelanggan keluarga"
                        className="w-full bg-gray-700 border border-gray-600 rounded-md p-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-red-500 focus:border-red-500 transition"
                    />
                </Card>

                <Card>
                     <h3 className="text-lg font-semibold text-red-400 mb-3">Langkah-Langkah Aksi</h3>
                     <div className="flex gap-2 mb-4">
                        <input
                            type="text"
                            value={newStepText}
                            onChange={(e) => setNewStepText(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleAddStep()}
                            placeholder="Contoh: Latih teknik 'Feel, Felt, Found'"
                            className="flex-grow bg-gray-700 border border-gray-600 rounded-md p-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-red-500 focus:border-red-500 transition"
                        />
                         <Button onClick={handleAddStep} size="md">Tambah</Button>
                     </div>
                     <ul className="space-y-3">
                         {plan.steps.map(step => (
                             <li key={step.id} className="flex items-center justify-between bg-gray-900/50 p-3 rounded-md">
                                 <div className="flex items-center">
                                    <input
                                        type="checkbox"
                                        checked={step.completed}
                                        onChange={() => handleToggleStep(step.id)}
                                        className="h-5 w-5 rounded bg-gray-700 border-gray-600 text-red-600 focus:ring-red-500 cursor-pointer"
                                    />
                                     <span className={`ml-3 text-gray-200 ${step.completed ? 'line-through text-gray-500' : ''}`}>
                                         {step.text}
                                     </span>
                                 </div>
                                 <button onClick={() => handleDeleteStep(step.id)} className="text-gray-500 hover:text-red-500 transition-colors">
                                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                                 </button>
                             </li>
                         ))}
                         {plan.steps.length === 0 && (
                            <p className="text-center text-gray-500 py-4">Belum ada langkah aksi. Mulai tambahkan sekarang!</p>
                         )}
                     </ul>
                </Card>

                {plan.steps.length > 0 && (
                    <div className="text-center mt-8">
                        <Button onClick={handleClearPlan} variant="danger" size="sm">
                            Hapus Seluruh Rencana
                        </Button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default PersonalActionPlan;