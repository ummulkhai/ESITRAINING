import React from 'react';
import { View } from '../types';
import Button from './common/Button';
import Card from './common/Card';
import { IconClipboardList } from '../constants';

interface DashboardProps {
    setView: (view: View) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ setView }) => {
    return (
        <div className="space-y-8">
            <div className="text-center py-8">
                <h1 className="text-4xl md:text-5xl font-extrabold text-white tracking-tight">
                    Selamat Datang, <span className="text-red-500">Tim Sales PT Auto Jaya</span>
                </h1>
                <p className="mt-6 max-w-3xl mx-auto text-lg md:text-xl text-gray-300">
                    Platform ini dirancang untuk mempertajam senjata utama Anda: <strong>Kecerdasan Emosional & Sosial (KES)</strong>. Kuasai seni memahami pelanggan dan bangun kepercayaan untuk menutup lebih banyak penjualan.
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
                <Card className="flex flex-col items-center text-center p-8">
                    <div className="p-3 bg-gray-700 rounded-full mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.523 5.754 19 7.5 19s3.332-.477 4.5-1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.523 18.247 19 16.5 19s-3.332-.477-4.5-1.253" />
                        </svg>
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-2">Modul Pembelajaran</h2>
                    <p className="text-gray-300 mb-6 flex-grow">Pelajari 4 pilar KES yang disesuaikan untuk skenario penjualan otomotif.</p>
                    <Button onClick={() => setView('modules')} size="lg" className="w-full mt-auto">
                        Mulai Belajar
                    </Button>
                </Card>
                 <Card className="flex flex-col items-center text-center p-8">
                    <div className="p-3 bg-gray-700 rounded-full mb-4">
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-teal-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                           <path strokeLinecap="round" strokeLinejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3h9M7 16h6M7 12h6M7 8h6" />
                        </svg>
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-2">Sumber Artikel</h2>
                    <p className="text-gray-300 mb-6 flex-grow">Dapatkan wawasan tambahan dan perkaya pengetahuan Anda dari berbagai sumber.</p>
                    <Button onClick={() => setView('articles')} size="lg" className="w-full mt-auto">
                        Lihat Artikel
                    </Button>
                </Card>
                 <Card className="flex flex-col items-center text-center p-8">
                    <div className="p-3 bg-gray-700 rounded-full mb-4">
                        <IconClipboardList />
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-2">Rencana Aksi Pribadi</h2>
                    <p className="text-gray-300 mb-6 flex-grow">Ubah teori menjadi praktik. Buat rencana pribadi Anda untuk menerapkan KES.</p>
                    <Button onClick={() => setView('plan')} size="lg" className="w-full mt-auto">
                        Buat Rencana
                    </Button>
                </Card>
            </div>
        </div>
    );
};

export default Dashboard;