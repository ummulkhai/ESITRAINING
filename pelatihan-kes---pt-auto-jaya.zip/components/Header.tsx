import React from 'react';
import { View } from '../types';

interface HeaderProps {
    currentView: View;
    setView: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
    const navItems: { id: View; label: string }[] = [
        { id: 'dashboard', label: 'Dashboard' },
        { id: 'modules', label: 'Modul Belajar' },
        { id: 'articles', label: 'Sumber Artikel' },
        { id: 'plan', label: 'Rencana Aksi' },
    ];

    return (
        <header className="bg-gray-800/60 backdrop-blur-sm sticky top-0 z-50 shadow-md shadow-gray-900/50 border-b border-gray-700/50">
            <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center">
                        <div className="flex-shrink-0 text-white font-bold text-lg flex items-center gap-2">
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M2.929 10.293a1 1 0 011.414 0L10 15.95l5.657-5.657a1 1 0 111.414 1.414l-6.364 6.364a1 1 0 01-1.414 0L2.929 11.707a1 1 0 010-1.414z" />
                                <path d="M10 2a.75.75 0 01.75.75v10.5a.75.75 0 01-1.5 0V2.75A.75.75 0 0110 2z" />
                             </svg>
                             <div>
                                <span className="text-red-500">PT Auto Jaya</span>
                                <span className="text-xs font-medium text-gray-400 block -mt-1">Pelatihan KES</span>
                             </div>
                        </div>
                    </div>
                    <div className="hidden md:block">
                        <div className="ml-10 flex items-baseline space-x-1">
                            {navItems.map((item) => (
                                <button
                                    key={item.id}
                                    onClick={() => setView(item.id)}
                                    className={`transition-colors duration-200 text-sm font-semibold ${
                                        currentView === item.id
                                            ? 'bg-red-600 text-white'
                                            : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                                    } px-4 py-2 rounded-md`}
                                >
                                    {item.label}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </nav>
        </header>
    );
};

export default Header;