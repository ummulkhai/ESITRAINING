import React from 'react';
import { ARTICLES } from '../constants';
import Card from './common/Card';

const ArticleSource: React.FC = () => {
    return (
        <div>
            <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-white sm:text-4xl">Sumber Artikel & Wawasan</h2>
                <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">Perkaya pengetahuan Anda dengan intisari dari berbagai artikel terkemuka tentang penjualan dan kecerdasan emosional.</p>
            </div>
            <div className="max-w-4xl mx-auto grid gap-6 md:grid-cols-1 lg:grid-cols-1">
                {ARTICLES.map((article, index) => (
                    <Card key={index} className="flex flex-col md:flex-row items-start p-6">
                        <div className="flex-shrink-0 mr-6 mb-4 md:mb-0 bg-gray-700 p-3 rounded-full">{article.icon}</div>
                        <div className="flex-grow">
                            <h3 className="text-xl font-bold text-white">{article.title}</h3>
                            <p className="text-sm text-gray-400 mt-1 mb-4 italic">{article.source}</p>
                            <h4 className="font-semibold text-red-400 mb-2">Poin Kunci:</h4>
                             <ul className="space-y-2 list-disc list-inside text-gray-300">
                                {article.keyTakeaways.map((point, pIndex) => (
                                    <li key={pIndex}>{point}</li>
                                ))}
                            </ul>
                        </div>
                    </Card>
                ))}
            </div>
        </div>
    );
};

export default ArticleSource;
