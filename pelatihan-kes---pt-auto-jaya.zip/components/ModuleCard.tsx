import React, { useState } from 'react';
import { Module } from '../types';

interface ModuleCardProps {
    module: Module;
}

const ModuleCard: React.FC<ModuleCardProps> = ({ module }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="border border-gray-700 rounded-lg bg-gray-800/50 overflow-hidden">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full p-5 text-left flex justify-between items-center hover:bg-gray-700/50 transition-colors duration-200"
                aria-expanded={isOpen}
            >
                <div className="flex items-center">
                    <div className="flex-shrink-0 mr-4 bg-gray-700 p-2 rounded-full">{module.icon}</div>
                    <div>
                        <h3 className="text-lg font-bold text-white">{module.title}</h3>
                        <p className="text-sm text-gray-400 mt-1">{module.summary}</p>
                    </div>
                </div>
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className={`h-6 w-6 text-gray-400 transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
            </button>
            <div
                className={`transition-all duration-300 ease-in-out ${isOpen ? 'max-h-screen' : 'max-h-0'}`}
                style={{ transitionProperty: 'max-height, padding' }}
            >
                <div className="px-5 pb-5 pt-2 border-t border-gray-700/50">
                    {module.content.map((section, index) => (
                        <div key={index} className="mt-4">
                            <h4 className="font-semibold text-red-400 text-md">{section.heading}</h4>
                            <ul className="mt-2 space-y-2 list-disc list-inside text-gray-300">
                                {section.points.map((point, pIndex) => (
                                    <li key={pIndex}>{point}</li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ModuleCard;
