import { ReactNode } from 'react';

export type View = 'dashboard' | 'modules' | 'articles' | 'plan';

export interface Module {
    icon: ReactNode;
    title: string;
    summary: string;
    content: {
        heading: string;
        points: string[];
    }[];
}

export interface Article {
    icon: ReactNode;
    title: string;
    source: string;
    keyTakeaways: string[];
}

export interface ActionStep {
    id: number;
    text: string;
    completed: boolean;
}

export interface ActionPlan {
    goal: string;
    steps: ActionStep[];
}